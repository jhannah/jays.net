#!/usr/bin/perl

use strict;
use warnings;
use File::Find;

# EDIT BELOW: this is the root directory where the patient files are
my $patientFileRoot = "/mnt/images/patient";

# get the hospital names and push into a hash key'd by hospital id
my %hospitals;
open (HOSPITALS, "hospitals.csv") or die $!;
while(my $line = <HOSPITALS>){
	chomp($line);
	my @fields = split(",", $line);

	my $temp = [];
	push(@$temp, $fields[1]);

	$hospitals{$fields[0]} = $temp;
}


# now get patients and start calculating file counts and sizes
# EDIT BELOW:  change the name of the file to october to do October
open (PATIENTS, "september.csv") or die $!;
#open (PATIENTS, "october.csv") or die $!;
while (my $patinfo = <PATIENTS>){
	chomp($patinfo);
	my @ids = split(",", $patinfo);

	my $patientId = $ids[0];
	my $hospitalId = $ids[1];

	my $firstDir = substr ($patientId, 0, 2);
	my $secondDir = substr ($patientId, 2, 2);

	my $patientDir = "$patientFileRoot/$firstDir/$secondDir/$patientId";

	my $sizefiles = 0;
	my $numfiles = 0;

	find(sub { $sizefiles += -s if -f }, $patientDir);

	find(sub { $numfiles += 1 if -f }, $patientDir);

	my @array = @{ $hospitals{$hospitalId} };

	my $arraysize = scalar(@array);
	if ($arraysize == 1){
		push(@array, $numfiles);
		push(@array, $sizefiles);
	}
	else{
		$array[1]+=$numfiles;
		$array[2]+=$sizefiles;
	}
     
        @{$hospitals{$hospitalId}} = @array;

}

# print output
for my $k (keys (%hospitals)){
        print("Hospital Key: [$k], ");

	my @array = @{$hospitals{$k}};

        print("Hospital Name: [$array[0]] ");
        if(scalar(@array) > 1){
            print("Files: [$array[1]], Size: [$array[2]] bytes");
        }

        print("\n");
}